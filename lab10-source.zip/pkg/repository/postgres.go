package repository

import (
	"context"
	"database/sql"
	"fmt"
	"time"

	"DevOps/pkg/course"
	_ "github.com/lib/pq"
)

type Postgres struct{ db *sql.DB }

var _ course.Repository = (*Postgres)(nil)

func NewPostgres(ctx context.Context, dsn string) (*Postgres, error) {
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		return nil, err
	}
	if err = db.PingContext(ctx); err == nil {
		_, err = db.ExecContext(ctx, `CREATE TABLE IF NOT EXISTS courses (
   id uuid PRIMARY KEY, title text NOT NULL, instructor text NOT NULL,
   duration integer NOT NULL CHECK (duration>0), published boolean NOT NULL,
   created_at timestamptz NOT NULL)`)
	}
	if err != nil {
		db.Close()
		return nil, err
	}
	return &Postgres{db: db}, nil
}
func (p *Postgres) Close() error { return p.db.Close() }
func (p *Postgres) Create(ctx context.Context, c course.Course) error {
	_, err := p.db.ExecContext(ctx, `INSERT INTO courses VALUES ($1,$2,$3,$4,$5,$6)`, c.ID, c.Title, c.Instructor, c.Duration, c.Published, c.CreatedAt)
	return err
}

type scanner interface{ Scan(...any) error }

func readCourse(row scanner) (course.Course, error) {
	var c course.Course
	var created time.Time
	err := row.Scan(&c.ID, &c.Title, &c.Instructor, &c.Duration, &c.Published, &created)
	if err != nil {
		return course.Course{}, err
	}
	c.CreatedAt = created.UTC().Format(time.RFC3339)
	return c, nil
}
func (p *Postgres) GetByID(ctx context.Context, id string) (course.Course, error) {
	return readCourse(p.db.QueryRowContext(ctx, `SELECT id,title,instructor,duration,published,created_at FROM courses WHERE id::text=$1`, id))
}
func (p *Postgres) Publish(ctx context.Context, id string) error {
	res, err := p.db.ExecContext(ctx, `UPDATE courses SET published=true WHERE id::text=$1`, id)
	if err != nil {
		return err
	}
	n, err := res.RowsAffected()
	if err == nil && n == 0 {
		return fmt.Errorf("course not found")
	}
	return err
}
func (p *Postgres) List(ctx context.Context) ([]course.Course, error) {
	rows, err := p.db.QueryContext(ctx, `SELECT id,title,instructor,duration,published,created_at FROM courses ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	result := []course.Course{}
	for rows.Next() {
		c, err := readCourse(rows)
		if err != nil {
			return nil, err
		}
		result = append(result, c)
	}
	return result, rows.Err()
}
