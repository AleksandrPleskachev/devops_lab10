#!/usr/bin/env bash
set -euo pipefail
export COMPOSE_PROJECT_NAME=devops_lab10
mkdir -p evidence
exec > >(tee evidence/compose.txt) 2>&1
cp .env.example .env
set -x
c() { docker compose "$@"; }
wait_api() {
  for _ in {1..30}; do
    if curl -s -o /dev/null "http://127.0.0.1:$1/courses/missing"; then return; fi
    sleep 1
  done
  c logs app
  return 1
}
c config --services
c config --format json | jq 'del(.services[].environment.POSTGRES_PASSWORD)'
c up -d --build
wait_api 8080
url=http://127.0.0.1:8080/courses
id=$(curl -fsS -H 'Content-Type: application/json' -d '{"title":"DevOps","instructor":"Tutor","duration":30}' "$url" | jq -er '.id')
curl -fsS "$url/$id" | jq -ec 'select(.published==false)'
curl -fsS -X POST "$url/$id/publish"
curl -fsS "$url/$id" | jq -ec 'select(.published==true)'
c exec -T app sh -c 'id; pwd'
timeout 3s docker compose logs -f app || test "$?" -eq 124
c stop app
c ps -a app
curl -fsS http://127.0.0.1:8081 | grep 'Courses static from volume'
c start app
wait_api 8080
sed -i 's/^APP_PORT=.*/APP_PORT=9091/' .env
c up -d
wait_api 9091
url=http://127.0.0.1:9091/courses
c port app 8080
if curl -s --max-time 2 http://127.0.0.1:8080/ >/dev/null; then exit 1; fi
c down
docker volume inspect devops_lab10_pgdata --format '{{.Name}}'
c up -d
wait_api 9091
curl -fsS "$url/$id" | jq -ec 'select(.published==true)'
c down -v
if docker volume inspect devops_lab10_pgdata; then exit 1; fi
c up -d
wait_api 9091
test "$(curl -s -o /dev/null -w '%{http_code}' "$url/$id")" = 404
c down -v
docker compose -f compose.yaml -f compose.failure.yaml up -d --build
for _ in {1..15}; do
  if c logs app | grep -F 'cannot connect to db'; then break; fi
  sleep 1
done
c logs app | grep -F 'cannot connect to db'
c down -v
c up -d --build
wait_api 9091
c ps
c logs app | grep -F 'postgres repository ready'
c down -v
echo 'PASS: Compose, PostgreSQL persistence, Nginx, DNS, startup recovery'
